import WpBackend from './WpBackend';
const w = new WpBackend();
w.init();
