import WpGutenberg from './WpGutenberg';
const w = new WpGutenberg();
w.init();
