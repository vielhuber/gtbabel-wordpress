import WysiwygEditor from './WysiwygEditor';
const w = new WysiwygEditor();
w.init();
