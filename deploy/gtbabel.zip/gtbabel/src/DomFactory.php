<?php

namespace ScopedGtbabel\vielhuber\gtbabel;

class DomFactory
{
    function __construct(\ScopedGtbabel\vielhuber\gtbabel\Utils $utils = null, \ScopedGtbabel\vielhuber\gtbabel\Data $data = null, \ScopedGtbabel\vielhuber\gtbabel\Host $host = null, \ScopedGtbabel\vielhuber\gtbabel\Settings $settings = null, \ScopedGtbabel\vielhuber\gtbabel\Tags $tags = null, \ScopedGtbabel\vielhuber\gtbabel\Log $log = null)
    {
        $this->utils = $utils ?: new \ScopedGtbabel\vielhuber\gtbabel\Utils();
        $this->data = $data ?: new \ScopedGtbabel\vielhuber\gtbabel\Data();
        $this->host = $host ?: new \ScopedGtbabel\vielhuber\gtbabel\Host();
        $this->settings = $settings ?: new \ScopedGtbabel\vielhuber\gtbabel\Settings();
        $this->tags = $tags ?: new \ScopedGtbabel\vielhuber\gtbabel\Tags();
        $this->log = $log ?: new \ScopedGtbabel\vielhuber\gtbabel\Log();
    }
    function modifyContentFactory($content, $type)
    {
        $dom = new \ScopedGtbabel\vielhuber\gtbabel\Dom($this->utils, $this->data, $this->host, $this->settings, $this->tags, $this->log, $this);
        $content = $dom->modifyContent($content, $type);
        return $content;
    }
}
