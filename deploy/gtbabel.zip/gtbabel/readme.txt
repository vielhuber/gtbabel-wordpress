=== Gtbabel ===
Contributors: vielhuber
Tags: 
Donate link: https://vielhuber.de
Requires at least: 5.3.2
Tested up to: 5.3.2
Requires PHP: 7.2
Stable tag: 5.8.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

== Installation ==

== Frequently Asked Questions ==

== Changelog ==

== Upgrade Notice ==
