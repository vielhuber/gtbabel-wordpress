<?php

namespace ScopedGtbabel\vielhuber\gtbabelpro;

class DomFactory
{
    function __construct(\ScopedGtbabel\vielhuber\gtbabelpro\Utils $utils = null, \ScopedGtbabel\vielhuber\gtbabelpro\Data $data = null, \ScopedGtbabel\vielhuber\gtbabelpro\Host $host = null, \ScopedGtbabel\vielhuber\gtbabelpro\Settings $settings = null, \ScopedGtbabel\vielhuber\gtbabelpro\Tags $tags = null, \ScopedGtbabel\vielhuber\gtbabelpro\Log $log = null)
    {
        $this->utils = $utils ?: new \ScopedGtbabel\vielhuber\gtbabelpro\Utils();
        $this->data = $data ?: new \ScopedGtbabel\vielhuber\gtbabelpro\Data();
        $this->host = $host ?: new \ScopedGtbabel\vielhuber\gtbabelpro\Host();
        $this->settings = $settings ?: new \ScopedGtbabel\vielhuber\gtbabelpro\Settings();
        $this->tags = $tags ?: new \ScopedGtbabel\vielhuber\gtbabelpro\Tags();
        $this->log = $log ?: new \ScopedGtbabel\vielhuber\gtbabelpro\Log();
    }
    function modifyContentFactory($content, $type)
    {
        $dom = new \ScopedGtbabel\vielhuber\gtbabelpro\Dom($this->utils, $this->data, $this->host, $this->settings, $this->tags, $this->log, $this);
        $content = $dom->modifyContent($content, $type);
        return $content;
    }
}
