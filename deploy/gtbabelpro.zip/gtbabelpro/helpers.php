<?php



if (!\function_exists('gtbabelpro_current_lng')) {
    function gtbabelpro_current_lng()
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->data->getCurrentLanguageCode();
    }
}
if (!\function_exists('gtbabelpro_source_lng')) {
    function gtbabelpro_source_lng()
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->settings->getSourceLanguageCode();
    }
}
if (!\function_exists('gtbabelpro_referer_lng')) {
    function gtbabelpro_referer_lng()
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->host->getRefererLanguageCode();
    }
}
if (!\function_exists('gtbabelpro_language_label')) {
    function gtbabelpro_language_label($lng)
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->settings->getLabelForLanguageCode($lng);
    }
}
if (!\function_exists('gtbabelpro_languages')) {
    function gtbabelpro_languages()
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->settings->getSelectedLanguageCodes();
    }
}
if (!\function_exists('gtbabelpro_default_language_codes')) {
    function gtbabelpro_default_language_codes()
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->settings->getDefaultLanguageCodes();
    }
}
if (!\function_exists('gtbabelpro_default_languages')) {
    function gtbabelpro_default_languages()
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->settings->getDefaultLanguages();
    }
}
if (!\function_exists('gtbabelpro_default_settings')) {
    function gtbabelpro_default_settings($args = [])
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->settings->setupSettings($args);
    }
}
if (!\function_exists('gtbabelpro_languagepicker')) {
    function gtbabelpro_languagepicker()
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->data->getLanguagePickerData();
    }
}
if (!\function_exists('gtbabelpro__')) {
    function gtbabelpro__($str, $lng_target = null, $lng_source = null, $context = null)
    {
        global $gtbabelpro;
        if ($gtbabelpro === null) {
            $gtbabelpro = new \ScopedGtbabel\vielhuber\gtbabelpro\Gtbabel();
        }
        return $gtbabelpro->translate($str, $lng_target, $lng_source, $context);
    }
}
