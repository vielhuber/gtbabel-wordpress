import Tooltips from './Tooltips';
const w = new Tooltips();
w.init();
