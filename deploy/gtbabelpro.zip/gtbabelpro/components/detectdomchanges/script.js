import DetectDomChanges from './DetectDomChanges';
const d = new DetectDomChanges();
d.init();
