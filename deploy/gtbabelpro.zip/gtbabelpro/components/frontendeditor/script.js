import FrontendEditor from './FrontendEditor';
const f = new FrontendEditor();
f.init();
